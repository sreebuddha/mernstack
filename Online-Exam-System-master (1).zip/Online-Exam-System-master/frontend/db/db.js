// db.js
module.exports = function() {
  return {
    users: require('./users.json'),
    payload: require('./payload.json'),
    payload1: require('./payload1.json'),
    payload2: require('./payload2.json'),
    payload3: require('./payload3.json')
  }
}
